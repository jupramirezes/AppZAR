import { users, properties, contactMessages, propertyValuations, type User, type InsertUser, type Property, type InsertProperty, type ContactMessage, type InsertContactMessage, type PropertyValuation, type InsertPropertyValuation } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getProperties(): Promise<Property[]>;
  getProperty(id: number): Promise<Property | undefined>;
  getPropertiesByType(type: string): Promise<Property[]>;
  getPropertiesByZone(zone: string): Promise<Property[]>;
  getFeaturedProperties(): Promise<Property[]>;
  createProperty(property: InsertProperty): Promise<Property>;
  
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessages(): Promise<ContactMessage[]>;
  
  createPropertyValuation(valuation: InsertPropertyValuation): Promise<PropertyValuation>;
  getPropertyValuations(): Promise<PropertyValuation[]>;
  calculatePropertyValue(valuationData: InsertPropertyValuation): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private properties: Map<number, Property>;
  private contactMessages: Map<number, ContactMessage>;
  private propertyValuations: Map<number, PropertyValuation>;
  private currentUserId: number;
  private currentPropertyId: number;
  private currentMessageId: number;
  private currentValuationId: number;

  constructor() {
    this.users = new Map();
    this.properties = new Map();
    this.contactMessages = new Map();
    this.propertyValuations = new Map();
    this.currentUserId = 1;
    this.currentPropertyId = 1;
    this.currentMessageId = 1;
    this.currentValuationId = 1;

    // Initialize with sample properties
    this.initializeProperties();
  }

  private initializeProperties() {
    const sampleProperties: InsertProperty[] = [
      {
        title: "Apartamento Moderno El Poblado",
        description: "Hermoso apartamento de 2 habitaciones con vista panorámica y acabados de lujo",
        price: 2800000,
        type: "arriendo",
        zone: "El Poblado",
        bedrooms: 2,
        bathrooms: 2,
        area: 85,
        imageUrl: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: true,
      },
      {
        title: "Casa Familiar Laureles",
        description: "Casa de 3 pisos con jardín privado y garaje para 2 carros",
        price: 680000000,
        type: "venta",
        zone: "Laureles",
        bedrooms: 4,
        bathrooms: 3,
        area: 180,
        imageUrl: "https://images.unsplash.com/photo-1570129477492-45c003edd2be?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: true,
      },
      {
        title: "Estudio Ejecutivo Envigado",
        description: "Perfecto para profesionales, completamente amoblado",
        price: 1600000,
        type: "arriendo",
        zone: "Envigado",
        bedrooms: 1,
        bathrooms: 1,
        area: 45,
        imageUrl: "https://images.unsplash.com/photo-1484154218962-a197022b5858?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: false,
      },
      {
        title: "Penthouse de Lujo",
        description: "Exclusivo penthouse con terraza privada y vista 360°",
        price: 1200000000,
        type: "venta",
        zone: "El Poblado",
        bedrooms: 3,
        bathrooms: 4,
        area: 220,
        imageUrl: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: true,
      },
      {
        title: "Apartamento Acogedor Sabaneta",
        description: "Ideal para parejas, cerca al metro y centros comerciales",
        price: 1900000,
        type: "arriendo",
        zone: "Sabaneta",
        bedrooms: 2,
        bathrooms: 2,
        area: 65,
        imageUrl: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: false,
      },
      {
        title: "Casa Moderna Itagüí",
        description: "Casa nueva en conjunto cerrado con piscina y zonas comunes",
        price: 420000000,
        type: "venta",
        zone: "Itagüí",
        bedrooms: 3,
        bathrooms: 2,
        area: 120,
        imageUrl: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        featured: false,
      },
    ];

    sampleProperties.forEach(property => {
      this.createProperty(property);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getProperties(): Promise<Property[]> {
    return Array.from(this.properties.values());
  }

  async getProperty(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }

  async getPropertiesByType(type: string): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(
      (property) => property.type === type,
    );
  }

  async getPropertiesByZone(zone: string): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(
      (property) => property.zone === zone,
    );
  }

  async getFeaturedProperties(): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(
      (property) => property.featured,
    );
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const id = this.currentPropertyId++;
    const property: Property = { 
      ...insertProperty, 
      id,
      featured: insertProperty.featured ?? false
    };
    this.properties.set(id, property);
    return property;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentMessageId++;
    const createdAt = new Date().toISOString();
    const message: ContactMessage = { ...insertMessage, id, createdAt };
    this.contactMessages.set(id, message);
    return message;
  }

  async getContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }

  async createPropertyValuation(insertValuation: InsertPropertyValuation): Promise<PropertyValuation> {
    const id = this.currentValuationId++;
    const estimatedValue = await this.calculatePropertyValue(insertValuation);
    const createdAt = new Date().toISOString();
    const valuation: PropertyValuation = { 
      ...insertValuation, 
      id, 
      estimatedValue, 
      createdAt,
      hasParking: insertValuation.hasParking ?? false,
      hasElevator: insertValuation.hasElevator ?? false,
      hasBalcony: insertValuation.hasBalcony ?? false,
    };
    this.propertyValuations.set(id, valuation);
    return valuation;
  }

  async getPropertyValuations(): Promise<PropertyValuation[]> {
    return Array.from(this.propertyValuations.values());
  }

  async calculatePropertyValue(valuationData: InsertPropertyValuation): Promise<number> {
    // Base price per square meter by zone (in Colombian Pesos)
    const basePriceByZone: Record<string, number> = {
      "El Poblado": 8500000,
      "Laureles": 6800000,
      "Envigado": 7200000,
      "Sabaneta": 5500000,
      "Itagüí": 4800000,
      "Bello": 4200000,
      "La Estrella": 4500000,
    };

    const basePrice = basePriceByZone[valuationData.propertyZone] || 5000000;
    let totalValue = basePrice * valuationData.propertyArea;

    // Adjust for number of bedrooms
    if (valuationData.bedrooms >= 3) {
      totalValue *= 1.15;
    } else if (valuationData.bedrooms >= 2) {
      totalValue *= 1.08;
    }

    // Adjust for number of bathrooms
    if (valuationData.bathrooms >= 3) {
      totalValue *= 1.12;
    } else if (valuationData.bathrooms >= 2) {
      totalValue *= 1.05;
    }

    // Adjust for property age
    if (valuationData.propertyAge <= 5) {
      totalValue *= 1.1;
    } else if (valuationData.propertyAge <= 10) {
      totalValue *= 1.05;
    } else if (valuationData.propertyAge >= 20) {
      totalValue *= 0.9;
    }

    // Adjust for property condition
    const conditionMultipliers = {
      excellent: 1.15,
      good: 1.05,
      fair: 0.95,
      poor: 0.8,
    };
    totalValue *= conditionMultipliers[valuationData.propertyCondition as keyof typeof conditionMultipliers] || 1;

    // Additional features
    if (valuationData.hasParking) totalValue *= 1.08;
    if (valuationData.hasElevator) totalValue *= 1.05;
    if (valuationData.hasBalcony) totalValue *= 1.03;

    return Math.round(totalValue);
  }
}

export const storage = new MemStorage();
